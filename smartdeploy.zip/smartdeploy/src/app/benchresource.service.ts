import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { buname } from './buname';
import { Resource } from './Resource';

@Injectable({
  providedIn: 'root'
})
/**
 * Service Class
 */
export class BenchresourceService {
  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  constructor(private http: HttpClient) { }
  /**
   * method to get count employees based on Bu
   * @param bu1 
   */
  public getDataByBu(bu1: buname): Observable<any> {
    return this.http.post<buname>("http://ec2-3-222-138-79.compute-1.amazonaws.com:8080/buemployeedata", bu1, { headers: this.headers });

  }
  /**
   * method to fetch employee details based on Bu
   * 
   */

  public getEmployeedata() {
    return this.http.get<Resource[]>("http://ec2-3-222-138-79.compute-1.amazonaws.com:8080/completeemployeedetails");
  }



}
