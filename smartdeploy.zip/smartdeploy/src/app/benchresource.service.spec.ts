import { TestBed } from '@angular/core/testing';

import { BenchresourceService } from './benchresource.service';

describe('BenchresourceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BenchresourceService = TestBed.get(BenchresourceService);
    expect(service).toBeTruthy();
  });
});
