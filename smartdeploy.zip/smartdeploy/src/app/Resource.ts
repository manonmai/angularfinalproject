export class Resource{
empId :string;
name :string;
email :string;
location :string;
grade:string;
fulfilment: string ;
}