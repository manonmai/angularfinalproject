export class buname{
bu:string;
}