export class Employee{
    bench : number;
    deployed:number;
    // emp_id : string ;
    // active_flag :boolean ;
    // created_by : string ;
    // created_date: Date;
    // updated_by : string;
    // updated_date :Date;
    // bench_age :number;
    // bu : string;
    // date_of_joining :Date;
    // email_id : string;
    // emp_name : string;
    // gender : string;
    // global_id : string;
    // is_resume : boolean;
    // is_training_assigned  : boolean;
    // location : string;
    // mobile :number;
    // resume : string;
    // spoc_id : string;
    // tcg_employee : string;
    // bench_availability_id : string;
    // etap_tags_id : string;
    // password : string;
    // is_new_user : string;
}