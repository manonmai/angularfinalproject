import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';
import { FormsModule } from '@angular/forms';
import { HighchartsChartComponent } from 'highcharts-angular';
// import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { DialogService } from 'primeng/api';
import { TableComponent } from '../table/table.component';
import { ButtonModule } from 'primeng/button';

@NgModule({
  declarations: [HomeComponent, HighchartsChartComponent, TableComponent],
  imports: [
    CommonModule,
    HomeRoutingModule,
    FormsModule,
    DynamicDialogModule,
    ButtonModule
   
  ],
  providers: [DialogService],
  entryComponents: [TableComponent],
  exports: [HomeComponent, TableComponent]

})
export class HomeModule {
  benchresource() {

  }

}
