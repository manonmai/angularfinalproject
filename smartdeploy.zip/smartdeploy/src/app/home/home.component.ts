import { Component, OnInit } from '@angular/core';
import { buname } from '../buname';
import { Employee } from '../Employee';
import * as Highcharts from 'highcharts';
import { BenchresourceService } from '../benchresource.service'
import { DialogService } from 'primeng/api';
import { TableComponent } from '../table/table.component';
@Component({
   selector: 'app-home',
   templateUrl: './home.component.html',
   styleUrls: ['./home.component.scss'],

})
export class HomeComponent implements OnInit {
   buName: string;
   bu1: buname = { bu: null };
   chartOptions;
   barchart;
   linechart;
   highcharts = Highcharts;
   employee: Employee = { bench: 0, deployed: 0 };
   display = false;
   display1;

   constructor(private benchresource: BenchresourceService,
      public dialogService: DialogService) { }



   ngOnInit() {
   }
   /**
    * method to show dialog box
    */

   showDialog = function () {
      const ref = this.dialogService.open(TableComponent, {
         header: 'Employee',
         width: '70%',
         height: '52%'
      });
   }
   /**
    * method to get data based on bu and display in charts
    */
   public benchresource1() {
      this.highcharts = Highcharts
      this.display = true;
      this.bu1.bu = this.buName;
      var obj = this.benchresource.getDataByBu(this.bu1).subscribe(data => {
         this.employee = data;
         this.chartOptions = {
            chart: {

               plotShadow: false
            },
            title: {
               text: "Resources"
            },
            tooltip: {
               pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
               pie: {
                  allowPointSelect: true,
                  cursor: 'pointer',
                  dataLabels: {
                     enabled: true,
                     format: '<b>{point.name}%</b>: {point.percentage:.1f} %',
                     style: {
                        color: 'black'
                     }
                  }
               }
            },
            series: [{
               type: 'pie',
               data: [
                  ['bench', data[0][0]],
                  ['deployed', data[0][1]]

               ]
            }]
         };
         this.barchart = {
            chart: {
               type: 'bar'
            },
            title: {
               text: "Resources"
            },
            legend: {
               layout: 'vertical',
               align: 'left',
               verticalAlign: 'top',
               floating: true,
               borderWidth: 1,

               shadow: true
            },
            xAxis: {
               categories: ['Bench', 'Selected'], title: {
                  text: 'fullfilment'
               }

            },
            yAxis: {
               title: {
                  text: 'Bench resource', align: 'high'
               },

            },
            plotOptions: {
               bar: {
                  dataLabels: {
                     enabled: false
                  }
               }
            },
            credits: {
               enabled: false
            },
            series: [
               {
                  name: 'Resource',
                  data: [data[0][0], data[0][1]],

               },
               
            ]
         },
            this.linechart = {
               chart: {
                  type: "spline"
               },
               title: {
                  text: "Resources"
               },
               xAxis: {
                  categories: ["Bench", "Selected"]
               },
               yAxis: {
                  title: {
                     text: "Resource"
                  }
               },
               series: [{
                  name: 'Resource',
                  data: [data[0][0], data[0][1]]
               }]
            };

      })



   }
}
