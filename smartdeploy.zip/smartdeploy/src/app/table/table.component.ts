import { Component, OnInit } from '@angular/core';
import { Resource } from '../Resource';
import { BenchresourceService } from '../benchresource.service'
import { ExcelService } from '../excel.service';
import { Sort } from '@angular/material/sort';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnInit {
  resource: Resource[] = [
    {
      empId: "", name: null, email: null, location: null, grade: null, fulfilment: null
    }];
  filterGrade: string;
  filterLocation: string;
  filterFulfilment: string;
  Id: string;
  sortedData: Resource[];



   constructor(private benchresource: BenchresourceService, private excelService: ExcelService) {
    this.sortedData = this.resource.slice();
  }
  sortData(sort: Sort) {
    const data = this.resource.slice();
    console.log(this.resource);
    if (!sort.active || sort.direction === '') {
      this.sortedData = data;
      return;
    }

    this.sortedData = data.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {
        case 'empId': return this.compare(a.empId, b.empId, isAsc);
        case 'name': return this.compare(a.name, b.name, isAsc);
        case 'email': return this.compare(a.email, b.email, isAsc);
        case 'location': return this.compare(a.location, b.location, isAsc);
        case 'grade': return this.compare(a.grade, b.grade, isAsc);
        case 'fulfilment': return this.compare(a.fulfilment, b.fulfilment, isAsc);
        default: return 0;
      }
    });
  }

  compare(a: number | string, b: number | string, isAsc: boolean) {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
  }

  public ngOnInit() {

    this.benchresource.getEmployeedata().subscribe(data => {
      this.resource = data;
      console.log(this.resource);
    });
  }
 public searchGrade() {
    if (this.filterGrade != "") {
      this.resource = this.filterByGrade(this.resource, this.filterGrade);
    }
    else if (this.filterGrade == "") {
      this.ngOnInit();
    }

  }
  public searchLocation() {
    if (this.filterLocation != "") {
      this.resource = this.filterByLocation(this.resource, this.filterLocation);
    }
    else if (this.filterLocation == "") {
      this.ngOnInit();
    }

  }

  public searchFulfil() {
    if (this.filterFulfilment != "") {
      this.resource = this.filterByFulfilment(this.resource, this.filterFulfilment);
    }
    else if (this.filterFulfilment == "") {
      this.ngOnInit();
    }

  }
  public downloadExcel(): void {
    this.excelService.exportAsExcelFile(this.resource, 'sample');
  }
  public simpleClone(obj: any) {
    return Object.assign({}, obj);
  }
  public filterByGrade(array, grade) {
    return array.filter((item: any) => item[4] === grade);
  }
  public filterByLocation(array, location) {
    return array.filter((item: any) => item[3] == location);
  }
  public filterByFulfilment(array, fulfilment) {
    return array.filter((item: any) => item[5] === fulfilment);
  }

}

